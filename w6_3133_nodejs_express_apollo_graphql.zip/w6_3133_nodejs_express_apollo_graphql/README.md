https://medium.com/better-programming/a-simple-crud-app-using-graphql-nodejs-mongodb-78319908f563

https://medium.com/the-node-js-collection/making-your-node-js-work-everywhere-with-environment-variables-2da8cdf6e786