const {
  GraphQLObjectType,
  GraphQLString,
  GraphQLID,
  GraphQLList,
  GraphQLInt,
  GraphQLFloat,
  GraphQLSchema,
  GraphQLNonNull
} = require("graphql");
const resolvers = require("./resolvers");

const MovieType = new GraphQLObjectType({
  name: "Movie",
  fields: () => ({
    id: { type: GraphQLID },
    name: { type: GraphQLString },
    director_name: { type: GraphQLString },
    production_house: { type: GraphQLString },
    release_date: { type: GraphQLString },
    rating: { type: GraphQLFloat },
  }),
});

const RootQuery = new GraphQLObjectType({
  name: "RootQueryType",
  fields: {
    movies: { type: new GraphQLList(MovieType), resolve: resolvers.Query.movies },
    movie: {
      type: MovieType,
      args: { id: { type: GraphQLID } },
      resolve: resolvers.Query.movie
    },
  },
});

const Mutation = new GraphQLObjectType({
  name: "Mutation",
  fields: {
    addMovie: {
      type: MovieType,
      args: {
        name: { type: GraphQLNonNull(GraphQLString) },
        director_name: { type: GraphQLNonNull(GraphQLString) },
        production_house: { type: GraphQLNonNull(GraphQLString) },
        release_date: { type: GraphQLNonNull(GraphQLString) },
        rating: { type: GraphQLNonNull(GraphQLFloat) },
      },
      resolve: resolvers.Mutation.addMovie,
    },
    updateMovie: {
      type: MovieType,
      args: {
        id: { type: GraphQLNonNull(GraphQLID) },
        name: { type: GraphQLString },
        director_name: { type: GraphQLString },
        production_house: { type: GraphQLString },
        release_date: { type: GraphQLString },
        rating: { type: GraphQLFloat },
      },
      resolve: resolvers.Mutation.updateMovie,
    },
    deleteMovie: {
      type: MovieType,
      args: { id: { type: GraphQLNonNull(GraphQLID) } },
      resolve: resolvers.Mutation.deleteMovie,
    },
  },
});

module.exports = new GraphQLSchema({ query: RootQuery, mutation: Mutation });
