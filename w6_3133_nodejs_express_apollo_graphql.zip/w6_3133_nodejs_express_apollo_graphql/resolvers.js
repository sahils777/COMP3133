const mongoose = require("mongoose");
const Movie = require("./models/Movie");

const resolvers = {
  Query: {
    movies: async () => {
      try {
        return await Movie.find();
      } catch (error) {
        throw new Error("Error fetching movies: " + error.message);
      }
    },
    movie: async (_, args) => {
      try {
        if (!mongoose.Types.ObjectId.isValid(args.id)) {
          throw new Error("Invalid ObjectId format");
        }
        const movie = await Movie.findById(args.id);
        if (!movie) {
          throw new Error("Movie not found");
        }
        return movie;
      } catch (error) {
        throw new Error("Error fetching movie: " + error.message);
      }
    },
  },

  Mutation: {
    addMovie: async (_, args) => {
      try {
        const newMovie = new Movie(args);
        return await newMovie.save();
      } catch (error) {
        throw new Error("Error adding movie: " + error.message);
      }
    },
    updateMovie: async (_, args) => {
      try {
        if (!mongoose.Types.ObjectId.isValid(args.id)) {
          throw new Error("Invalid ObjectId format");
        }
        const updatedMovie = await Movie.findByIdAndUpdate(
          args.id,
          args,
          { new: true }
        );
        if (!updatedMovie) {
          throw new Error("Movie not found");
        }
        return updatedMovie;
      } catch (error) {
        throw new Error("Error updating movie: " + error.message);
      }
    },
    deleteMovie: async (_, args) => {
      try {
        if (!mongoose.Types.ObjectId.isValid(args.id)) {
          throw new Error("Invalid ObjectId format");
        }
        const deletedMovie = await Movie.findByIdAndDelete(args.id);
        if (!deletedMovie) {
          throw new Error("Movie not found");
        }
        return deletedMovie;
      } catch (error) {
        throw new Error("Error deleting movie: " + error.message);
      }
    },
  },
};

module.exports = resolvers;
