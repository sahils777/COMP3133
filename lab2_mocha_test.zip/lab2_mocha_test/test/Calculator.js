const { expect } = require('chai');
const calculator = require('../app/calculator');

describe('Calculator Tests', () => {
    describe('Addition Tests', () => {
        it('should return 18 when adding 9 and 9', () => {
            expect(calculator.add(9, 9)).to.equal(18);
            console.log('PASS: add(9,9) expected result 18');
        });

        it('should fail when adding 5 and 2 expecting 10', () => {
            expect(calculator.add(5, 2)).to.not.equal(10);
            console.log('FAIL: add(5,2) expected result 10');
        });
    });

    describe('Subtraction Tests', () => {
        it('should return 0 when subtracting 5 and 5', () => {
            expect(calculator.sub(5, 5)).to.equal(0);
            console.log('PASS: sub(5,5) expected result 0');
        });

        it('should fail when subtracting 5 and 2 expecting 5', () => {
            expect(calculator.sub(5, 2)).to.not.equal(5);
            console.log('FAIL: sub(5,2) expected result 5');
        });
    });

    describe('Multiplication Tests', () => {
        it('should return 20 when multiplying 5 and 4', () => {
            expect(calculator.mul(5, 4)).to.equal(20);
            console.log('PASS: mul(5,4) expected result 20');
        });

        it('should fail when multiplying 5 and 2 expecting 17', () => {
            expect(calculator.mul(5, 2)).to.not.equal(17);
            console.log('FAIL: mul(5,2) expected result 17');
        });
    });

    describe('Division Tests', () => {
        it('should return 7 when dividing 14 by 2', () => {
            expect(calculator.div(14, 2)).to.equal(7);
            console.log('PASS: div(14,2) expected result 7');
        });

        it('should fail when dividing 10 by 2 expecting 3', () => {
            expect(calculator.div(10, 2)).to.not.equal(3);
            console.log('FAIL: div(10,2) expected result 3');
        });
    });
});
